const express = require('express')
const router = express.Router()
const connection = require('../../connection/connection')
const token_manager = require('./register_users')

router.post("/login", async(req, res) => {
    const userData = req.body
    // res.json(token_manager.get_generate_access_token({"user_id" : req.params.user_id}))
    const sql = `SELECT * FROM user WHERE username = ? AND password = ?`
    const show_product = await conection.execute(sql,
        (err, result, fields) => {
            res.json(result)
        })
})

router.post("/check_authen" , (req, res) => {
    const jwt_status = token_manager.check_authen(req)
    if(jwt_status != false) {
        res.send(jwt_status)
    } else {
        res.send("token error !!@#$")
    }
})

module.exports = router