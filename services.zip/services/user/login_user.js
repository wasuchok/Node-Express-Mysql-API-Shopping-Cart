const express = require('express')
const router = express.Router()
const connection = require('../../connection/connection')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt')

const secret_key = "bce41fce62428b8347035e84051025c065b8742579dd22c29faf55f04b3cde61af4587d101c0f0e7f29fce65e8b12662dfc4365a6d6c376a06dd8e879dd444f4"

router.post('/login_user', async (req, res) => {
    connection.execute(
        'SELECT * FROM user WHERE email = ?',
        [req.body.email],
        function(err, users, fields) {
            if(err) { res.json({status: 'error', message: err}); return }
            if(users.length == 0) { res.json({status : 'error', message : "no user found"}); return } 
            bcrypt.compare(req.body.password, users[0].password, function(err, isLogin) {
                console.log(isLogin);
                // if(isLogin) {
                //     res.json({status :'success', message : 'login success'});
                // } else {
                //     res.json({status : 'error', message : 'wrong password'});
                // }
            })
        }
    )
})

// router.post('/login_user', function(req,res,next){
//     connection.execute(
//       'SELECT * FROM user WHERE email = ?',
//       [req.body.email],
//       function(err,users,fields) {
//         if(err) {
//           res.json({status: 'error', message: err})
//           return
//         }
//         if(users.length == 0){
//           res.json({status: 'no user found', message: err})
//           return
//         }
//         bcrypt.compare(req.body.password,users[0].password,function(err,islogin){
//           if(islogin){
//             const token = jwt.sign({ id : users[0].id, email : users[0].email , role : users[0].role }, secret_key, { expiresIn : '1h'})
//             res.json({status: 'ok', message: 'login Successfuly', token})
//             console.log(users[0].role);
//           }else{
//             res.json({status: 'error', message: 'login failed'})
//           }
//         })
//       }
//     )
//   })

module.exports = router